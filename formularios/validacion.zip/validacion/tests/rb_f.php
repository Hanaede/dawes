<?php
/**
 * Test para radio-buttom
 * @author KIKE MJ
 */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="rb_p.php" method="post">
        <input type="radio" name="rb" value="1">uno
        <input type="radio" name="rb" value="2">dos
        <input type="radio" name="rb" value="3">tres
        <br/>

        <input type="submit" name="enviar">
    </form>
</body>
</html>