<?php
/**
 * Comprobaciónd e checkbox
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="cb_p.php" method="post">
        <input type="checkbox" name="cb" value="1">uno
        <input type="checkbox" name="cb" value="2">dos
        <input type="checkbox" name="cb" value="3">tres
        <br/>

        <input type="submit" name="enviar">
    </form>
</body>
</html>