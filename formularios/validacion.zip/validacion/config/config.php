<?php

$agenero = array("Hombre", "Mujer", "Otro");
$avehichulos = array("Bicicleta", "Coche", "Patinete");
$aopciones = array(
    array("codigo" => "1", "color" => "rojo"),
    array("codigo" => "2", "color" => "verde"),
    array("codigo" => "3", "color" => "amarillo")
);
$acoches = array("BMW", "Audi", "Volvo"); // checkbox