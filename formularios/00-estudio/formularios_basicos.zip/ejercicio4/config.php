<?php
$hobbies = array("Leer", "Salir a la montaña", "Fotografía", "Música");
$paises = array("España", "Francia", "Italia", "Portugal");